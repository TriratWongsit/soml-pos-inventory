import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.jsx';
import './styles.css';
import { initTheme } from './services/theme.js';

initTheme();

createRoot(document.getElementById('root')).render(<React.StrictMode><App /></React.StrictMode>);
